from flask import Flask, render_template, request
from pyresparser import ResumeParser
import os
import zipfile
import shutil

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
EXTRACT_FOLDER = 'extracted'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['EXTRACT_FOLDER'] = EXTRACT_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

if not os.path.exists(EXTRACT_FOLDER):
    os.makedirs(EXTRACT_FOLDER)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/parse_resume', methods=['POST'])
def parse_resume():
    if request.method == 'POST':
        uploaded_files = request.files.getlist('resumes')
        results = []

        for resume_file in uploaded_files:
            if resume_file.filename.endswith('.zip'):
                zip_path = os.path.join(app.config['UPLOAD_FOLDER'], resume_file.filename)
                resume_file.save(zip_path)
                extract_dir = os.path.join(app.config['EXTRACT_FOLDER'], os.path.splitext(resume_file.filename)[0])

                # Extract the contents of the zip file
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_dir)

                # Parse each resume file within the extracted directory
                for root, _, files in os.walk(extract_dir):
                    for file in files:
                        if file.endswith('.pdf') or file.endswith('.docx'):
                            file_path = os.path.join(root, file)
                            data = ResumeParser(file_path).get_extracted_data()

                            # Replace missing fields with empty strings or lists
                            name = data.get('name', '')
                            email = data.get('email', '')
                            skills = data.get('skills', [])
                            experience = data.get('experience', [])

                            # Append result to the results list
                            results.append({'name': name, 'email': email, 'skills': skills, 'experience': experience})

                # Remove the extracted directory after parsing resumes
                shutil.rmtree(extract_dir)

            else:
                # Handle individual resume files (PDF or DOCX)
                if resume_file.filename != '':
                    resume_path = os.path.join(app.config['UPLOAD_FOLDER'], resume_file.filename)
                    resume_file.save(resume_path)

                    if resume_path.endswith('.pdf') or resume_path.endswith('.docx'):
                        data = ResumeParser(resume_path).get_extracted_data()

                        # Replace missing fields with empty strings or lists
                        name = data.get('name', '')
                        email = data.get('email', '')
                        skills = data.get('skills', [])
                        experience = data.get('experience', [])

                        # Append result to the results list
                        results.append({'name': name, 'email': email, 'skills': skills, 'experience': experience})

        return render_template('result.html', results=results)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
