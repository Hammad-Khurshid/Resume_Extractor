from flask import Flask, render_template, request
from pyresparser import ResumeParser
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
EXTRACT_FOLDER = 'extracted'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['EXTRACT_FOLDER'] = EXTRACT_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

if not os.path.exists(EXTRACT_FOLDER):
    os.makedirs(EXTRACT_FOLDER)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/parse_resume', methods=['POST'])
def parse_resume():
    if request.method == 'POST':
        uploaded_files = request.files.getlist('resumes')
        results = []

        for resume_file in uploaded_files:
            if resume_file.filename != '':
                resume_path = os.path.join(app.config['UPLOAD_FOLDER'], resume_file.filename)
                resume_file.save(resume_path)
                
                if resume_path.endswith('.pdf') or resume_path.endswith('.docx'):
                    data = ResumeParser(resume_path).get_extracted_data()
                
                    # Replace missing fields with empty strings or lists
                    result = {
                        'name': data.get('name', 'N/A'),
                        'email': data.get('email', 'N/A'),
                        'skills': data.get('skills', []),
                        'experience': data.get('experience', [])
                    }
                    
                    # Ensure all fields are not None
                    for key in result:
                        if result[key] is None:
                            result[key] = '' if key != 'experience' else []
                    
                    results.append(result)
        
        return render_template('result.html', results=results)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
